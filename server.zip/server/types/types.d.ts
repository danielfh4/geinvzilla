import "express-session";
import type { User as AppUser } from "../schema"; // ou o caminho correto para seu tipo User

declare module "express-session" {
  interface SessionData {
    userId?: string;
    isAdmin?: boolean;
  }
}

declare global {
  namespace Express {
    interface Request {
      user?: AppUser;
      file?: Express.Multer.File;
    }
  }
}